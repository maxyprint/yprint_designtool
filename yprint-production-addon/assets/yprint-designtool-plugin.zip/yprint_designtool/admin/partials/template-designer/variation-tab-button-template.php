<template id="designer-tab-button-template">
    <button type="button" class="tab-button">
        <span class="color-preview"></span>
        <span class="default-badge"><?php esc_html_e('Default', 'octo-print-designer'); ?></span>
    </button>
</template>