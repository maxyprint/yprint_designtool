<template id="designer-variation-size-item-template">
    <label class="size-item size-checkbox">
        <input type="checkbox">
    </label>
</template>