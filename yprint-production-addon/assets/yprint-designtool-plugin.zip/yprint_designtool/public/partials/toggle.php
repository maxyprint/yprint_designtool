<label class="octo-toggle-switch">
  <input type="checkbox">
  <span class="slider"></span>
</label>